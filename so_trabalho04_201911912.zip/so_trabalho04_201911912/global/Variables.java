package global;

public class Variables {
  public static final String[] ALOCATION_ALGS = {
    "1 - Simple Contiguous Allocation",
    "2 - Absolute Static Partitioned Allocation",
    "3 - Relocatable Static Partitioned Allocation"
  };
}
